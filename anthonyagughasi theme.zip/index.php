<?php get_header(); ?>
<main>
    <h1>Welcome to AnthonyAgughasi Theme</h1>
    <p>This is a fully customizable WordPress theme.</p>
</main>
<?php get_footer(); ?>
