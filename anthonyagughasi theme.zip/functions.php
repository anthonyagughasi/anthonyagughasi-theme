<?php
if (!defined('ABSPATH')) {
    exit;
}

function anthonyagughasi_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    add_theme_support('customize-selective-refresh-widgets');
    register_nav_menus([
        'primary' => __('Primary Menu', 'anthonyagughasi'),
        'footer'  => __('Footer Menu', 'anthonyagughasi'),
    ]);
}
add_action('after_setup_theme', 'anthonyagughasi_setup');

function anthonyagughasi_scripts() {
    wp_enqueue_style('anthonyagughasi-style', get_stylesheet_uri());
    wp_enqueue_script('anthonyagughasi-script', get_template_directory_uri() . '/js/main.js', ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'anthonyagughasi_scripts');

function anthonyagughasi_widgets_init() {
    register_sidebar([
        'name'          => __('Sidebar', 'anthonyagughasi'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'anthonyagughasi'),
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ]);
}
add_action('widgets_init', 'anthonyagughasi_widgets_init');

function anthonyagughasi_customize_register($wp_customize) {
    $wp_customize->add_section('anthonyagughasi_colors', [
        'title'    => __('Theme Colors', 'anthonyagughasi'),
        'priority' => 30,
    ]);
    $wp_customize->add_setting('primary_color', [
        'default'   => '#0073aa',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', [
        'label'    => __('Primary Color', 'anthonyagughasi'),
        'section'  => 'anthonyagughasi_colors',
        'settings' => 'primary_color',
    ]));
}
add_action('customize_register', 'anthonyagughasi_customize_register');
