<?php wp_footer(); ?>
<footer>
    <p>&copy; <?php echo date('Y'); ?> AnthonyAgughasi Theme. All rights reserved.</p>
</footer>
</body>
</html>
