document.addEventListener("DOMContentLoaded", function() {
    console.log("AnthonyAgughasi theme is active");
});
